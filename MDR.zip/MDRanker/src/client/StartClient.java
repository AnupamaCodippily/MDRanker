package client;

public class StartClient {

	public static void main(String[] args) {
		
		Client mdClient = new Client();
		System.out.println("Client started");
	}

}
