package client.testing;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Vector;

import server.DataHandler;

public class RequestTesting  {
	public static void main (String args []) {
//		String name = "";
//		
//		try {
//			
//			
//			DataHandler	handler = (DataHandler) Naming.lookup("rmi://localhost:8081/MDRankerServer/Data");
//		
//		HashMap request = new HashMap<String, String>();
//		
//		request.put("category","hospital");
//		
//		// Test to fetch all Doctors
//		Vector<HashMap<String, String>> vector = handler.fetchAllDataOfType(request);
//		
//		for (HashMap<String, String> m : vector) {
//			m.forEach((k,v) -> {
//				System.out.println(v);
//			});
//		}
//		
//		}
//		catch (RemoteException rex) {
//			
//		} catch (MalformedURLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (NotBoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}
}
