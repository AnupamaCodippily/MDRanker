package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import server.reviewables.Hospital;

public interface ServerInterface extends Remote{

	
//	Accessing the database
////	public HospitalReview fetchHospitalData (int id) throws RemoteException;
//	public Review fetchReviewableData (int id) throws RemoteException;
//	public void deleteReviewableData (int id) throws RemoteException;
//	public Review fetchReviewData (Review review) throws RemoteException;
//	public void deleteReviewData (int id) throws RemoteException;
//	public void fetchQuestions(int id) throws RemoteException;
//	public HospitalReview createReviewableData (Hospital hospital) throws RemoteException;
//	
////  Validation
//	public boolean isValid (Review review) throws RemoteException;
//	
////  Searching for doctors or hospitals in an area
//	public Reviewable find(Location location);
	
}
